# PANGERAN STR V2 OFFICIAL — Website

Isi:
- Jasa Post Akun
- Jaslog
- Jasweb
- WhatsApp resmi: 083186682297
- QRIS/DANA menggunakan gambar QRIS yang kamu upload
- Musik MP3 yang kamu upload
- PWA manifest + service worker agar bisa dipasang ke Chrome/Home Screen
- Tombol order membuat pesan WhatsApp otomatis

## Penting tentang musik autoplay
Chrome/Android umumnya memblokir autoplay audio dengan suara tanpa interaksi pengguna. Jadi website menyediakan tombol Putar Musik. Setelah pengguna pernah mengaktifkan musik, preferensi disimpan di browser. Saat tab/page keluar (visibility hidden), musik dijeda.

## Agar permanen di Google Chrome
1. Upload folder ini ke hosting HTTPS, misalnya Netlify/GitHub Pages/hosting sendiri.
2. Buka URL HTTPS di Chrome.
3. Pilih menu Chrome > "Tambahkan ke layar utama" / "Install app" jika tersedia.
4. Website akan punya alamat online permanen selama hosting/domain tetap aktif.

## Catatan
- "Chat otomatis" di sini berarti tombol order otomatis membuat teks WhatsApp. Balasan otomatis dari WhatsApp membutuhkan WhatsApp Business/API atau layanan chatbot.
- QRIS harus diverifikasi nama penerima dan nominal sebelum pembayaran.
